
public class Mypoint {

}
